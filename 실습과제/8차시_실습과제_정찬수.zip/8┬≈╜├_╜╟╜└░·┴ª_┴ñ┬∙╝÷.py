width = int(input("가로길이를 입력하세요 : "))
height = int(input("세로길이를 입력하세요 : "))
avg = width * height / 2

print("삼각형 넓이는 ",avg,"입니다.")
      

str1 = str2 = "Hello world"
str3 = "Hello,Python"
print("str1과 str2는 : ", not(str1!=str2))
print("str1과 str3는 : ", str1==str3)

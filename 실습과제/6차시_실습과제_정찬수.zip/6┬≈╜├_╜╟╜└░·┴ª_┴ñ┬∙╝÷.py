apple = 4000
banana = 2000
price = apple*5 + banana*3
print(price)

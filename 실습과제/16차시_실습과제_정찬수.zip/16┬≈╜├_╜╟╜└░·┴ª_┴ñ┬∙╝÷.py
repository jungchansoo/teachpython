icecream = dict(zip(["메로나","폴라포","빵바레","죠스바","월드콘"],[1000,1200,1800,1200,1500]))
print("수정전 : ",icecream)

icecream.update({"죠스바":1500,"폴라포":1800})
print("수정후 : ",icecream)

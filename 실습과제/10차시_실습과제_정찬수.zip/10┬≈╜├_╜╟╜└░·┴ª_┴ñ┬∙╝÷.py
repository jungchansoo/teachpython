my_list = ['a']
my_listt = ['b','c']
my_listtt = ['d','e','f']

print(my_list)
print(my_listt)
print(my_listtt)

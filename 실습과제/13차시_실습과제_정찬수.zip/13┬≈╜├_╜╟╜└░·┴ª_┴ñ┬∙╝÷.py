phone_number = "010-1212-3434"
print(phone_number[0:3],phone_number[4:8],phone_number[9:13],sep="")

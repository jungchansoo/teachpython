num = int(input("값을 입력하세요: "))

if num < 0:
    num = 0
elif num > 300:
    num = 300
else :
    num = num-30

print(num)

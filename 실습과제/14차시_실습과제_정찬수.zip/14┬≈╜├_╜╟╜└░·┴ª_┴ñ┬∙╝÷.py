closing_price = [["09월11일","09월10일","09월09일","09월08일","09월07일"],
                 ["금","목","수","화","월"],
                 [488500,500500,501000,461500,474500]]

max_price = max(closing_price[2])
min_price = min(closing_price[2])
max_index = closing_price[2].index(max_price)
min_index = closing_price[2].index(min_price)

print(closing_price[0][max_index],closing_price[1][max_index],closing_price[2][max_index])
print(closing_price[0][min_index],closing_price[1][min_index],closing_price[2][min_index])

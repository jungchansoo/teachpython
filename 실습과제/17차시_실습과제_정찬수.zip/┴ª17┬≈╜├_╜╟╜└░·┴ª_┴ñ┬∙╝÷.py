num = input("값읍 입력하세요:")
if int(num) == 52:
    print("짝수")

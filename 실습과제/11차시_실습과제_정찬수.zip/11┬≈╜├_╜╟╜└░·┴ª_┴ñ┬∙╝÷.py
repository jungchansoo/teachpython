bnum = tuple(range(2,99,2))
print(bnum)
